package main;

import javax.faces.event.ActionEvent;

import model.AppModuleImpl;

import oracle.adf.model.BindingContext;
import oracle.adf.model.binding.DCBindingContainer;
import oracle.adf.model.binding.DCDataControl;
import oracle.adf.view.rich.component.rich.data.RichTable;
import oracle.adf.view.rich.component.rich.input.RichInputText;

import oracle.adf.view.rich.component.rich.nav.RichLink;
import oracle.adf.view.rich.context.AdfFacesContext;

import oracle.jbo.ApplicationModule;
import oracle.jbo.ViewObject;

public class main {
    private RichTable wasQtySearch;
    private RichTable dryProcessSearch;
    private RichTable wetProcessSearch;
    private RichTable chemicalPriceSearch;
    private RichTable detailsSearch;
    private RichInputText drySamSumSearch;
    private RichInputText produceSamSumSearch;
    private RichInputText dryQuantitySearch;
    private RichInputText wetPTimeSearch;
    private RichInputText cheSumSearch;
    private RichInputText cheQuantitySumSearch;
    private RichInputText washQsumSearch;
    private RichLink idSearch;

    public main() {
    }
    public ApplicationModule getAppM(){
           DCBindingContainer bindingContainer =
               (DCBindingContainer)BindingContext.getCurrent().getCurrentBindingsEntry();
           //BindingContext bindingContext = BindingContext.getCurrent();
           DCDataControl dc =
               bindingContainer.findDataControl("AppModuleDataControl"); // Name of application module in datacontrolBinding.cpx
           AppModuleImpl appM = (AppModuleImpl)dc.getDataProvider();
           return appM;
       }
       AppModuleImpl appM = (AppModuleImpl)this.getAppM();
     
     public void setWasQtySearch(RichTable wasQtySearch) {
        this.wasQtySearch = wasQtySearch;
    }

    public RichTable getWasQtySearch() {
        return wasQtySearch;
    }

    public void saearchAction(ActionEvent actionEvent) {
        // Add event code here...
        String id;
        id = "";
        ViewObject searchVO = appM.getsearchLovVO1();
        try{
           id = searchVO.getCurrentRow().getAttribute("SystemId").toString();
        }
        catch(Exception e){
                           id = " ";
                     }
       
        ViewObject sysIdVO = appM.getwashQtyVO1();
        ViewObject  sysVO = appM.getdryProcessVO1();
        ViewObject wetVO = appM.getwetProcessVO1();
        ViewObject chPVO = appM.getchemicalPriceVO1();
        ViewObject deVO;
        deVO = appM.getdetailsVO1();
        ViewObject dryProSum = appM.getdryProcessSumVO1();
        ViewObject wetProTime = appM.getwetProcessSumVO1();
        ViewObject chePSum= appM.getcheSumVO1();
        ViewObject washQQSum =appM.getwashQtySumVO1();
        
        sysIdVO.setNamedWhereClauseParam("sytem", id);
        sysVO.setNamedWhereClauseParam("sym", id);
        wetVO.setNamedWhereClauseParam("wetSysId", id);
        chPVO.setNamedWhereClauseParam("CPSystemId", id);
        deVO.setNamedWhereClauseParam("det", id);
        dryProSum.setNamedWhereClauseParam("dryPSum", id);
        wetProTime.setNamedWhereClauseParam("wetPSum", id);
        chePSum.setNamedWhereClauseParam("cheSum", id);
        washQQSum.setNamedWhereClauseParam("washQSum",id);
        
        sysIdVO.executeQuery();
        sysVO.executeQuery();
        wetVO.executeQuery();
        chPVO.executeQuery();
        deVO.executeQuery();
        dryProSum.executeQuery();
        wetProTime.executeQuery();
        chePSum.executeQuery();
        washQQSum.executeQuery();
      
        
        
//        AdfFacesContext.getCurrentInstance().addPartialTarget(wasQtySearch);
//        AdfFacesContext.getCurrentInstance().addPartialTarget(dryProcessSearch);
//        AdfFacesContext.getCurrentInstance().addPartialTarget(wetProcessSearch);
//        AdfFacesContext.getCurrentInstance().addPartialTarget(chemicalPriceSearch);
//        AdfFacesContext.getCurrentInstance().addPartialTarget(detailsSearch);
//        AdfFacesContext.getCurrentInstance().addPartialTarget(drySamSumSearch);
//        AdfFacesContext.getCurrentInstance().addPartialTarget(produceSamSumSearch);
//        AdfFacesContext.getCurrentInstance().addPartialTarget(dryQuantitySearch);
//        AdfFacesContext.getCurrentInstance().addPartialTarget(wetPTimeSearch);
//        AdfFacesContext.getCurrentInstance().addPartialTarget(cheSumSearch);
//        AdfFacesContext.getCurrentInstance().addPartialTarget(cheQuantitySumSearch);
//        AdfFacesContext.getCurrentInstance().addPartialTarget(washQsumSearch);
        
    }

    public void setDryProcessSearch(RichTable dryProcessSearch) {
        this.dryProcessSearch = dryProcessSearch;
    }

    public RichTable getDryProcessSearch() {
        return dryProcessSearch;
    }

    public void setWetProcessSearch(RichTable wetProcessSearch) {
        this.wetProcessSearch = wetProcessSearch;
    }

    public RichTable getWetProcessSearch() {
        return wetProcessSearch;
    }

    public void setChemicalPriceSearch(RichTable chemicalPriceSearch) {
        this.chemicalPriceSearch = chemicalPriceSearch;
    }

    public RichTable getChemicalPriceSearch() {
        return chemicalPriceSearch;
    }

    public void setDetailsSearch(RichTable detailsSearch) {
        this.detailsSearch = detailsSearch;
    }

    public RichTable getDetailsSearch() {
        return detailsSearch;
    }

    public void setDrySamSumSearch(RichInputText drySamSumSearch) {
        this.drySamSumSearch = drySamSumSearch;
    }

    public RichInputText getDrySamSumSearch() {
        return drySamSumSearch;
    }

    public void setProduceSamSumSearch(RichInputText produceSamSumSearch) {
        this.produceSamSumSearch = produceSamSumSearch;
    }

    public RichInputText getProduceSamSumSearch() {
        return produceSamSumSearch;
    }

    public void setDryQuantitySearch(RichInputText dryQuantitySearch) {
        this.dryQuantitySearch = dryQuantitySearch;
    }

    public RichInputText getDryQuantitySearch() {
        return dryQuantitySearch;
    }

    public void setWetPTimeSearch(RichInputText wetPTimeSearch) {
        this.wetPTimeSearch = wetPTimeSearch;
    }

    public RichInputText getWetPTimeSearch() {
        return wetPTimeSearch;
    }

    public void setCheSumSearch(RichInputText cheSumSearch) {
        this.cheSumSearch = cheSumSearch;
    }

    public RichInputText getCheSumSearch() {
        return cheSumSearch;
    }

    public void setCheQuantitySumSearch(RichInputText cheQuantitySumSearch) {
        this.cheQuantitySumSearch = cheQuantitySumSearch;
    }

    public RichInputText getCheQuantitySumSearch() {
        return cheQuantitySumSearch;
    }

    public void setWashQsumSearch(RichInputText washQsumSearch) {
        this.washQsumSearch = washQsumSearch;
    }

    public RichInputText getWashQsumSearch() {
        return washQsumSearch;
    }


    public void setIdSearch(RichLink idSearch) {
        this.idSearch = idSearch;
    }

    public RichLink getIdSearch() {
        return idSearch;
    }
}
